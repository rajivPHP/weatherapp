<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->params['breadcrumbs'][] = $this->title."weather ";
$weatherDataDec=array();
$weatherDataDec=json_decode($weatherData);
//echo "<pre>";
$arrayVal=array();
//echo $weatherDataDec['weather']->main;
foreach($weatherDataDec as $key){
	$arrayVal[]=$key;
}
//print_R($arrayVal);
?>
<div class="site-weather">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>
		<table class="table table-condensed">
		<thead>
		<th>Weather Info</th>
		<th>Description</th>
		<th>City</th>
		<th>Country</th>
		</thead>
		<tr>
		<td><?php echo $arrayVal[1][0]->main;?></td>
		<td><?php echo $arrayVal[1][0]->description;?></td>
		<td><?php echo $arrayVal[11]?></td>
		<td><?php echo $arrayVal[8]->country;?></td>
		</tr>
		</table>
    </p>

</div>
