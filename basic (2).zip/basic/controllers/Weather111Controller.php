<?php
//http://localhost:8080/weather?requestCity=bangalore
namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\ContactForm;

class WeatherController extends ActiveController
{
	public function actionIndex()
    {
		$weatherData=array();
		$requestCity=$_REQUEST['requestCity'];
		$request = curl_init('api.openweathermap.org/data/2.5/weather?q=""'.
		$requestCity.'&appid=061ae7071b3f946cf7de928c75b54215');
		//curl_setopt($request, CURLOPT_SAFE_UPLOAD, false);
		curl_setopt($request, CURLOPT_POST, true);
		//curl_setopt($request, CURLOPT_POSTFIELDS, $args);
		curl_setopt($request, CURLOPT_RETURNTRANSFER, true);
		$weatherData= curl_exec($request);
		curl_close($request);
		//print_r($request);exit;
        return $weatherData;
    }
}
